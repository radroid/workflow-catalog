# Skills endorsed by connections

- TypeScript
- Distributed Systems
- Payments Infrastructure
- Mentoring
